function h = plotRaster ( settings , params , data, model )

%% init
h = figure;

% plotting only for the relevant neurons
spike_mat = model.spike_times;
indices = 1 : 0.01 * params.num_exitatory;
indices = [indices, indices + 0.1 * params.num_exitatory];
num_neurons = length(indices);
spike_mat = spike_mat(indices,:);
spikes = bsxfun(@times,spike_mat,repmat((1:num_neurons/2)',2,1));
spikes(num_neurons/2 + 1 : end,:) = spikes(num_neurons/2 + 1 : end,:) - 0.5;
indices = spikes == 0 | spikes == -0.5;
t = repmat(data.timeVec,num_neurons,1);
c = [repmat([0 0 0],length(t(:))/2,1); repmat([0 1 0],length(t(:))/2,1)];
t(indices) = nan;
spikes(indices) = nan;
%% plot
hold on
scatter(t(:),spikes(:),5,c,'filled');
% for i = 1 : size(t,2)
%     scatter(t(1:num_neurons/2,i),spikes(1:num_neurons/2,i),5,'g','filled');
%     scatter(t(num_neurons/2+1:end,i),spikes(num_neurons/2+1:end,i),5,'k','filled');
%     drawnow;
% end
y = ylim;
X1 = [params.D_cue, params.D_cue + params.T_cue,params.D_cue + params.T_cue,params.D_cue];
Y1 = [0, 0, y(2), y(2)];
patch(X1,Y1,[1 1 1] * 0.1, 'FaceAlpha',0.3);


y = ylim;
X2 = [params.D_reactivating, params.D_reactivating + params.T_reactivating...
    params.D_reactivating + params.T_reactivating,params.D_reactivating];
Y2 = [0, 0, y(2), y(2)];
patch(X2,Y2,[1 1 1] * 0.7, 'FaceAlpha',0.3);

title('Raster Plot'), xlabel('Neuron #'), ylabel('Neuron #');
legend('Activated group','Non-activated group','Specific activating current','Non-specific activating current');
